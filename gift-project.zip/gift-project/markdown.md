<h1>The Cow Image Blurrer</h1>

I decided to make a browser extension that would help people who don't like cows. With this browser extension, you no longer have to look at cows – the image will be blurred!